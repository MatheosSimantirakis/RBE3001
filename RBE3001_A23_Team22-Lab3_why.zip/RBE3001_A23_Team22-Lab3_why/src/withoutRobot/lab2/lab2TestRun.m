clf
demo = lab2Test();
window = plot3(0,0,0);
demo.stick_man(window,[0 -90 -90 0]);
demo.fk3001([0 -90 -90 0]);