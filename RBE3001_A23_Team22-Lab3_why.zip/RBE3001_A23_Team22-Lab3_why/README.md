# Welcome to RBE 3001

Here we have provided you with all of the starter code that you will need for all 5 labs. This is the repo that you will clone to your personal machines and edit to complete your labs.

We recommend that you add the src file to your MATLAB path (this is described in lab 1) and then develop code for each lab in a separate folder (lab1, lab2, etc.). This way you can modify your Robot class without needing to copy it over to each new lab folder.

Here are some resources you may find useful:

https://emanual.robotis.com/docs/en/dxl/x/xm430-w350/

https://emanual.robotis.com/docs/en/software/dynamixel/dynamixel_sdk/overview/

https://emanual.robotis.com/docs/en/software/dynamixel/dynamixel_wizard2/
